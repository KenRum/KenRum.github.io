window.onload = function () {
   
	var width = 960;
    var height = 500;
            
    var svg = d3.select("svg")
                .attr("width", width)
                .attr("height", height)
                .style("border", "1px solid");
	
	// Map projection
    var projection = d3.geoMercator()
					   .center([107, 31])
					   .scale(100)
    				   .translate([width/2, height/2]);
	
    // Define path generator
	var path = d3.geoPath()
				 .projection(projection);
	
	
    d3.csv("Average.csv", function(data) {          
        var average2value = {};
        var minValue = Infinity;
        var maxValue = -1;
        data.forEach(function(d){
            var thisValue = d["K/D"];
            average2value[d["Server"]] = thisValue;
            
            minValue = Math.min(minValue, thisValue);
            maxValue = Math.max(maxValue, thisValue);
        });
        
        var value2range = d3.scaleLinear()
                            .domain([minValue, maxValue])
                            .range([0, 1])
        
        var range2color = d3.interpolateReds;
        

        var t = svg.selectAll("text")
            .data(data).enter()
            .append("text")
            .attr("x", 700)
            .attr("y", 200)
            .attr("opacity", 0)
            .attr("text-anchor", "middle")
            .attr("background", "black")
            .text(function(thisElement){
                var str = thisElement["Server"] + " " +"K/D :" + thisElement["K/D"];
                var strs = str.split(",");
                return strs ;
             });

         
            
	
	    d3.json("world.json", function(error, root) {
            if (error) 
		    	return console.error(error);
		    console.log(root.features);
		    
		    var server = svg.selectAll("path")
		    	            .data(root.features)
		    	            .enter()
		    	            .append("path")
		    	            .attr("stroke","#000")
		    	            .attr("stroke-width",1)
		    	            .attr("fill", function(d){
                                return range2color(value2range(average2value[d.properties.name]));
                            })
		    	            .attr("d", path )
                            .on("mouseover",function(d,i){
                                server.attr("opacity", 0.1)
                                d3.select(this)
                                  .attr("fill","yellow")
                                  .attr("opacity", 1);
                                t.attr("opacity", function(element,index){
                                    if (element["Server"] != d.properties.name){
                                        return 0
                                    }
                                })
                            })
                            .on("mouseout",function(d,i){
                                d3.select(this)
                                  .attr("fill",function(d){
                                    return range2color(value2range(average2value[d.properties.name]));
                                })
                                server.attr("opacity", 1)
                                t.attr("opacity", 0)
                            });
            
        });
        

        

	});

};