window.onload = function(){
    var svgCanvas = d3.select("svg")
        .attr("width", 1500)
        .attr("height", 600)
        .attr("class", "svgCanvas");
    
    d3.json("data.json", function(d){
        var node = d.nodes;
        var link = d.links;
        
        console.log(d); 
         
        for (var i=0; i<node.length; i++){ 
            var b = 0;
            var n = 0;
             for (var j=0; j<link.length; j++){
                if (link[j].node01 == node[i].id || link[j].node02 == node[i].id){
                 b = b + link[j].amount;   
                 n = n+1;
                };
             };
            node[i]["total"] = b;
            node[i]["number of location"] = n;
        };
        
        console.log(node);
        
        for (var j=0; j<link.length; j++){
            var node01x = 0;
            var node01y = 0;
            for (var i=0; i<node.length; i++){
                if (node[i].id == link[j].node01){
                    node01x = node[i].x;
                    node01y = node[i].y;
                };
            };
            link[j]["node01x"] = node01x;
            link[j]["node01y"] = node01y;
        };
        
        for (var j=0; j<link.length; j++){
            var node02x = 0;
            var node02y = 0;
            for (var i=0; i<node.length; i++){
                if (node[i].id == link[j].node02){
                    node02x = node[i].x;
                    node02y = node[i].y;
                };
            };
            link[j]["node02x"] = node02x;
            link[j]["node02y"] = node02y;
        };
        
                var minAmount = Infinity;
        var maxAmount = -1;
        link.forEach(function(thisD){
            var thisValue = thisD["amount"];
            minAmount = Math.min(minAmount, thisValue);
            maxAmount = Math.max(maxAmount, thisValue);
        });
        
        var amount2range = d3.scaleLinear()
            .domain([minAmount, maxAmount])
            .range([1, 5]);      
        
        
        svgCanvas.selectAll("lines")
            .data(link).enter()
            .append("line")
            .attr("x1", function(thisElement, index){
                return thisElement["node01x"]
            })
            .attr("y1", function(thisElement, index){
                return thisElement["node01y"]
            })
            .attr("x2", function(thisElement, index){
                return thisElement["node02x"]
            })
            .attr("y2", function(thisElement, index){
                return thisElement["node02y"]
            })
            .attr("stroke", "grey")
            .attr("stroke-width", function(thisElement, index){
               return amount2range(thisElement["amount"])
        });
        
        var minTotal = Infinity;
        var maxTotal = -1;
        node.forEach(function(thisD){
            var thisValue = thisD["total"];
            minTotal = Math.min(minTotal, thisValue);
            maxTotal = Math.max(maxTotal, thisValue);
        });
        
        var total2range = d3.scaleLinear()
            .domain([minTotal, maxTotal])
            .range([10, 30]);
        
        
        svgCanvas.selectAll("circles")
            .data(node).enter()
            .append("circle")
            .attr("cx", function(thisElement, index){
                return thisElement["x"];
            })
            .attr("cy", function(thisElement, index){
                return thisElement["y"]
            })
            .attr("r", function(thisElement, index){
                return total2range(thisElement["total"])
            })
            .attr("fill", "lightblue")
           // .on("mouseover", function(thisElement, index){
            //    svgCanvas.selectAll("circle")
            //        .attr("opacity", 0.5);
           //     d3.select(this)
          //          .attr("opacity", 1);
          //   })
          //   .on("mouseout", function(thisElement, index){
           //     svgCanvas.selectAll("circle")
           //         .attr("opacity", 1);
           //   })
        ;
        

        
        svgCanvas.selectAll("text")
            .data(node).enter()
            .append("text")
            .attr("x", function(thisElement, index){
                return thisElement["x"] ;
            })
            .attr("y", function(thisElement, index){
                return thisElement["y"] +50;
            })
            .attr("text-anchor", "middle")
            .attr("background", "white")
            .attr("opacity", 0)
            .text(function(thisElement, index){
                 return thisElement["id"] + " : " + "Total amount : " + thisElement["total"]  + "\r\n" +  "Connected locations : " + thisElement["number of location"] ;
        });
        
        var c = svgCanvas.selectAll("circle");
        var l = svgCanvas.selectAll("line");
        var t = svgCanvas.selectAll("text");
            
            
        c.on("mouseover", function(thisElement, index){
                c.attr("opacity", 0.1);
         //       l.attr("opacity",0.2);
                d3.select(this)
                    .attr("opacity", 1);
                t.attr("opacity", function(element, index){
                    if (element["id"] != thisElement["id"]){
                        return 0;
                    };
                });
                l.attr("opacity", function(element, index){
                    if (element["node01"] != thisElement["id"] && element["node02"] != thisElement["id"]){
                        return 0.1;
                    };
                });
             })
             .on("mouseout", function(thisElement, index){
                c.attr("opacity", 1);
                l.attr("opacity", 1);
                t.attr("opacity",0);
              })
        ;
        
      
    
        

    });
}