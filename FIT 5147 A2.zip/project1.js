window.onload = function () {
   
	var width = 1000;
    var height = 500;
    
    var padding = 100;
            
    var svg = d3.select("svg")
                .attr("width", width)
                .attr("height", height)
                .style("border", "1px solid");
    
    var filename = "solo-SEA.csv";
    $(".x").change(function(){
        var text = $(".x").val();
        if (text == "AS" ){
          filename = "solo-AS.csv"
          test_fun(filename);
        };
     });
    
    var dataset = ["AS","SEA"];

    
    
    
    
    
        
	console.log(filename);
    
    function test_fun(){
    d3.csv(filename, function(data) {
               
        
        var minX = Infinity;
        var maxX = -1;
        data.forEach(function(thisD){
            var thisValue = thisD["K/D"];
            minX = Math.min(minX, thisValue);
            maxX = Math.max(maxX, thisValue);
        });
        
        var minY = Infinity;
        var maxY = -1;
        data.forEach(function(thisD){
            var thisValue = thisD["Rating"];
            minY = Math.min(minY, thisValue);
            maxY = Math.max(maxY, thisValue);
        });
        
        
        var xScale = d3.scaleLinear()
            .domain([minX,maxX])
            .range([padding, width - 2*padding]);
        
        
        
        var yScale = d3.scaleLinear()
            .domain([minY, maxY])
            .range([height - padding,padding]);
        

       var xAxis = d3.axisBottom()
                    .scale(xScale)
                    .ticks(10);
        
       var yAxis = d3.axisLeft()
                    .scale(yScale)
                    .ticks(10);
        


        
        svg.selectAll("circles")
            .data(data).enter()
            .append("circle")
            .attr("cx", function(thisElement, index){
                return xScale(thisElement["K/D"])
            })
            .attr("cy", function(thisElement, index){
                return yScale(thisElement["Rating"])
            })
            .attr("r", 5)
            .attr("fill", "lightblue")
        
        var t = svg.selectAll("text")
            .data(data).enter()
            .append("text")
            .attr("x", function(thisElement, index){
                return xScale(thisElement["K/D"])
            })
            .attr("y", function(thisElement, index){
                return yScale(thisElement["Rating"])
            })
            .attr("opacity", 1)
            .attr("font-size", "10px")
            .attr("text-anchor", "middle")
            .attr("background", "black")
            .text(function(thisElement){
                var str = thisElement["Rating"] + " " +"K/D :" + thisElement["K/D"];
                var strs = str.split(",");
                return strs ;
             });
        
        
        svg.append("g")
           .attr("class", "axis")
           .attr("transform", "translate(0, 50)")
           .call(xAxis);
        
        svg.append("g")
           .attr("class", "axis")
           .attr("transform", "translate(50 , 0)")
           .call(yAxis);
        

        

	});
    };
   // test_fun(filename);
};